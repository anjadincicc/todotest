<template>
  <b-navbar type="dark" variant="info">
    <b-navbar-brand href="#">
      <h5>
        ELAB
        <b-badge variant="dark">TODO</b-badge>
      </h5>
    </b-navbar-brand>
  </b-navbar>
</template>
